import numpy
import sklearn
import os

from sklearn.neural_network import MLPClassifier
from sklearn.metrics import classification_report,confusion_matrix

# Need 0.18.2 version, for the NN
from Services.MainServices import make_histogram

print('The scikit-learn version is {}.'.format(sklearn.__version__))

dataDir = os.path.dirname(os.path.abspath(__file__))

mapping = {
        0: "5 rupees",
        1: "10 rupees",
        2: "20 rupees",
        3: "50 rupees",
        4: "100 rupees",
        5: "500 rupees",
        6: "1000 rupees",
}

# merged csv for training
training_data_file = numpy.genfromtxt('/Users/apple/PycharmProjects/CurrencyRecognitionNN/TrainingDataset.csv', delimiter=',', filling_values=0.0)

X_Train = training_data_file[:, 1:]
Y_Train = training_data_file[:, 0]

mlp = MLPClassifier(solver='sgd', alpha=1e-5, activation='logistic', max_iter=100, learning_rate='adaptive',
                        hidden_layer_sizes=(40,), random_state=1, verbose=False)

mlp.fit(X_Train, Y_Train)

userUploadData = numpy.genfromtxt('/Users/apple/PycharmProjects/CurrencyRecognitionNN/2500for20.csv', delimiter=',', filling_values=0.0)
X_Test = userUploadData[:]



predictions = mlp.predict(X_Test)
#predictions list ma jun value highest huncha tye value chai predict gareko ho MLP le
print predictions

for each in predictions:

    print mapping[each]